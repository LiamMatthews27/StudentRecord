/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.studentenrollment;

import ClientSide.LoginFrame;



/**
 *
 * @author matth
 */

public class StudentEnrollment {
    public static void main(String[] args) {
       LoginFrame cls = new LoginFrame();
        
    }
    
}
   