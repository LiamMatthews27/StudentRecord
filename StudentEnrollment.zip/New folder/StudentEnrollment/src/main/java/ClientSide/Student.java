/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClientSide;


import java.io.Serializable;

public class Student implements Serializable {
    private String studentName;
    private String studentLastName;
    private String studentNumber;
    private String studentEmail;
    private String studentPassword;

    public Student(String studentName, String studentLastName, String studentNumber, String studentEmail, String studentPassword) {
        this.studentName = studentName;
        this.studentLastName = studentLastName;
        this.studentNumber = studentNumber;
        this.studentEmail = studentEmail;
        this.studentPassword = studentPassword;
    }

    // Getters and setters for the fields

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentLastName() {
        return studentLastName;
    }

    public void setStudentLastName(String studentLastName) {
        this.studentLastName = studentLastName;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        this.studentPassword = studentPassword;
    }
}

