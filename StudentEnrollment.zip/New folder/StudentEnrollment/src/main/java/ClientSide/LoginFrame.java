

package ClientSide;
//!!!!!!!!!!!!!!!!!!!!!!!!!!MEANS THE START OF THE PAGES --- THE START OF A FORM ------ START OF THE PAGE THE BEGINING 
//?????????

import EnrollmentServer.Course;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class LoginFrame extends JFrame implements ActionListener {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame() {
        super("Student Enrollment System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setVisible(true);

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");

        JPanel loginPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(new JLabel());
        loginPanel.add(loginButton);

        getContentPane().add(loginPanel);

        loginButton.addActionListener((ActionListener) this);
    }

    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Add authentication logic
        String role = authenticateUser(username, password);

        if (role.equals("Admin")) {
            AdminPage adminPage = new AdminPage();
            adminPage.setVisible(true);
            this.dispose();
        } else if (role.equals("Student")) {
            StudentPage studentPage = new StudentPage();
            studentPage.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.");
            // Clear the fields
            usernameField.setText("");
            passwordField.setText("");
            usernameField.requestFocus();
        }
    }

    // Implement your authentication logic here
    private String authenticateUser(String username, String password) {
        // Replace this with your actual authentication logic
        if (username.equals("admin") && password.equals("password")) {
            return "Admin";
        } else if (username.equals("student") && password.equals("password")) {
            return "Student";
        } else {
            return "Error"; // Return "Error" for invalid credentials
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            }
        });
    }
}
class AdminPage extends JFrame {
    private JComboBox<String> comboBox;
    private JPanel contentPanel;
    private JPanel addStudentPanel;
    private JPanel addCoursePanel;
    private JPanel retrieveCoursePanel;
    private JPanel retrieveStudentPanel;  // Added for retrieving student data
    private JTextField nameField;
    private JTextField surnameField;
    private JTextField studentIDField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JTextField idField;
    private JTextField courseIDField;
    private JTextField courseNameField;
    private JTable studentTable;
    private DefaultTableModel tableModelStudents;
    private JTable courseTable;
    private DefaultTableModel tableModelCourses;
    private JPanel retrieveCourseWithStudent;

    public AdminPage() {
        super("Admin Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setResizable(true);

        getContentPane().setBackground(new Color(240, 240, 240));

        JLabel welcomeLabel = new JLabel("Welcome!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);

             //COMBOBOX TO SELECT A SPECIFIC FORM FOR THE ADMIN
        comboBox = new JComboBox<>(new String[]{"AddStudent", "AddCourse", "RetrieveCourses", "RetrieveStudent" , "RetrieveCourseWithStudent"});  // Added RetrieveStudent
        comboBox.setFont(new Font("Arial", Font.PLAIN, 16));

        
        //PANEL FOR EACH FORM 
        contentPanel = new JPanel(new CardLayout());
        addStudentPanel = new JPanel();
        addCoursePanel = new JPanel();
        retrieveCoursePanel = new JPanel();
        retrieveStudentPanel = new JPanel(); 
        retrieveCourseWithStudent = new JPanel();
        
// PANELS BACKGROUND COLOR
        retrieveCoursePanel.setBackground(Color.WHITE);
        addStudentPanel.setBackground(Color.WHITE);
        addCoursePanel.setBackground(Color.WHITE);
        retrieveStudentPanel.setBackground(Color.WHITE);  
        retrieveCourseWithStudent.setBackground(Color.WHITE);

        // CALLING THE PANEL TO ITS SPECIFIC FORM 
        contentPanel.add(addStudentPanel, "AddStudent");
        contentPanel.add(addCoursePanel, "AddCourse");
        contentPanel.add(retrieveCoursePanel, "RetrieveCourses");
        contentPanel.add(retrieveStudentPanel, "RetrieveStudent");  
        contentPanel.add(retrieveCourseWithStudent, "RetrieveCourseWithStudent");

        //ADD STUDENT FRAME !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        JTextField nameField = new JTextField(20);
        JTextField surnameField = new JTextField(20);
        JTextField studentIDField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        addStudentPanel.setLayout(new GridLayout(7, 2, 10, 10));
        addStudentPanel.add(new JLabel("Add Student Details"));
        addStudentPanel.add(new JLabel("Name:"));
        addStudentPanel.add(nameField);
        addStudentPanel.add(new JLabel("Surname:"));
        addStudentPanel.add(surnameField);
        addStudentPanel.add(new JLabel("Student ID:"));
        addStudentPanel.add(studentIDField);
        addStudentPanel.add(new JLabel("Email:"));
        addStudentPanel.add(emailField);
        addStudentPanel.add(new JLabel("Password:"));
        addStudentPanel.add(passwordField);

        tableModelStudents = new DefaultTableModel(new Object[]{"First Name", "Last Name", "Student ID", "Email", "Password"}, 0);
        studentTable = new JTable(tableModelStudents);

        retrieveStudentPanel.setLayout(new BorderLayout());
        retrieveStudentPanel.add(new JScrollPane(studentTable), BorderLayout.CENTER);

        
       
        JButton addStudentButton = new JButton("Add Student");
        addStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String studentName = nameField.getText();
                String studentSurname = surnameField.getText();
                String studentID = studentIDField.getText();
                String studentEmail = emailField.getText();
                String studentPassword = new String(passwordField.getPassword());

                addStudentToDatabase(studentID, studentName, studentSurname, studentEmail, studentPassword);

                nameField.setText("");
                surnameField.setText("");
                studentIDField.setText("");
                emailField.setText("");
                passwordField.setText("");
            }
        });

        addStudentPanel.add(addStudentButton);
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

//ADD COURSE FRAME !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        courseTable = new JTable();
        tableModelCourses = new DefaultTableModel(new Object[]{"ID", "Course ID", "Course Name"}, 0);
        courseTable.setModel(tableModelCourses);
        retrieveCoursePanel.setLayout(new BorderLayout());
        retrieveCoursePanel.add(new JScrollPane(courseTable), BorderLayout.CENTER);

        getContentPane().add(comboBox, BorderLayout.NORTH);
        getContentPane().add(contentPanel, BorderLayout.CENTER);

        idField = new JTextField(20);
        courseIDField = new JTextField(20);
        courseNameField = new JTextField(20);
        addCoursePanel.setLayout(new GridLayout(5, 2, 10, 10));
        addCoursePanel.add(new JLabel("Add Course Details"));
        addCoursePanel.add(new JLabel("ID:"));
        addCoursePanel.add(idField);
        addCoursePanel.add(new JLabel("Course ID:"));
        addCoursePanel.add(courseIDField);
        addCoursePanel.add(new JLabel("Course Name:"));
        addCoursePanel.add(courseNameField);

        JButton addCourseButton = new JButton("Add Course");
        addCourseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idValue = idField.getText();
                String courseIDValue = courseIDField.getText();
                String courseName = courseNameField.getText();

                addCourseToDatabase(idValue, courseIDValue, courseName);

                idField.setText("");
                courseIDField.setText("");
                courseNameField.setText("");
            }
        });

        addCoursePanel.add(addCourseButton);
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!END OF ADD COURSE FRAME 

//!!!!!!!!!!!!!!!!RETRIEVE COURSE AND STUDENT 
        comboBox.addActionListener(e -> {
            String selectedOption = (String) comboBox.getSelectedItem();
            CardLayout cl = (CardLayout) (contentPanel.getLayout());
            cl.show(contentPanel, selectedOption);

            if (selectedOption.equals("RetrieveCourses")) {
                retrieveCoursesData(); // CALL METHOD WHEN "RETREIVECOURSE" IS SELECTED 
            } else if (selectedOption.equals("RetrieveStudent")) {
                retrieveStudentData();  //CALL METHOD WHEN "RetrieveStudent" IS SELECTED
            } else if( selectedOption.equals ("RetrieveStudentWithCourse")){
                String studentID = "";
                 RetrieveCourseWithStudent(studentID);
            }
        });
    }
    
    private void RetrieveCourseWithStudent(String studentID) {
        // Query to retrieve courses for the specified student.
        String query = "SELECT c.CourseID, c.CourseName " +
                       "FROM Course c " +
                       "INNER JOIN StudentCourse sc ON c.ID = sc.CourseID " +
                       "INNER JOIN students s ON sc.StudentID = s.StudentID " +
                       "WHERE s.StudentID = ?";

        // Clear the current table data.
        tableModelCourses.setRowCount(0);
        
          String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String dbPassword = "123456";


        try (Connection connection = DriverManager.getConnection(url, username, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, studentID);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String courseID = resultSet.getString("CourseID");
                String courseName = resultSet.getString("CourseName");

                // Add the retrieved course data to the table.
                tableModelCourses.addRow(new Object[]{courseID, courseName});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving courses for the student: " + ex.getMessage());
        }
    }

    private void retrieveStudentData() {
        tableModelStudents.setRowCount(0);

        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String password = "123456";

        String query = "SELECT FirstName, LastName, StudentID, Email, Password FROM students";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                String studentID = resultSet.getString("StudentID");
                String email = resultSet.getString("Email");
                String dbPassword = resultSet.getString("Password");

                tableModelStudents.addRow(new Object[]{firstName, lastName, studentID, email, dbPassword});
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void showCourseTable(ArrayList<Course> courses) {
        retrieveCoursePanel.removeAll();

        tableModelCourses = new DefaultTableModel(new Object[]{"ID", "Course ID", "Course Name"}, 0);

        courseTable = new JTable(tableModelCourses);

        for (Course course : courses) {
            tableModelCourses.addRow(new Object[]{
                course.getID(),
                course.getCourseID(),
                course.getCourseName(),
            });
        }

        retrieveCoursePanel.setLayout(new BorderLayout());
        retrieveCoursePanel.add(new JScrollPane(courseTable), BorderLayout.CENTER);

        retrieveCoursePanel.revalidate();
        retrieveCoursePanel.repaint();
    }

    private void addCourseToDatabase(String courseID, String courseName, String courseDescription) {
        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String password = "123456";

        String query = "INSERT INTO Course (CourseID, CourseName, ID) VALUES (?, ?, ?)";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, courseID);
            preparedStatement.setString(2, courseName);
            preparedStatement.setString(3, courseDescription);

            int rowsInserted = preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Course added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Course addition failed.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void addStudentToDatabase(String studentID, String firstName, String lastName, String email, String password) {
        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String dbPassword = "123456";

        String query = "INSERT INTO students (StudentID, FirstName, LastName, Email, Password) VALUES (?, ?, ?, ?, ?)";

        try {
            Connection connection = DriverManager.getConnection(url, username, dbPassword);
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, studentID);
            statement.setString(2, firstName);
            statement.setString(3, lastName);
            statement.setString(4, email);
            statement.setString(5, password);

            statement.executeUpdate();

            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void retrieveCoursesData() {
        if (tableModelCourses == null) {
            tableModelCourses = new DefaultTableModel(new Object[]{"ID", "Course ID", "Course Name"}, 0);
            courseTable.setModel(tableModelCourses);
        }

        try {
            ArrayList<Course> courses = retrieveCoursesFromDatabase();
            showCourseTable(courses);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving courses: " + e.getMessage());
        }
    }

    private ArrayList<Course> retrieveCoursesFromDatabase() {
        ArrayList<Course> courses = new ArrayList<>();

        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String password = "123456";

        String query = "SELECT ID, CourseID, CourseName FROM Course";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String id = resultSet.getString("ID");
                String courseID = resultSet.getString("CourseID");
                String courseName = resultSet.getString("CourseName");

                courses.add(new Course(id, courseID, courseName));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving courses from the database: " + ex.getMessage());
            ex.printStackTrace();
        }

        return courses;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                AdminPage adminPage = new AdminPage();
                adminPage.setVisible(true);
            }
        });
    }
}

class StudentPage extends JFrame implements ActionListener {
    private JComboBox<String> courseComboBox;
    private JTable courseTable;
    private DefaultTableModel tableModel;
    private JButton enrollButton;

    public StudentPage() {
        super("Student Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 240, 240));

        JLabel titleLabel = new JLabel("Welcome, Student!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        courseComboBox = new JComboBox<>();
        courseTable = new JTable();

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Course Name");
        tableModel.addColumn("Description");
        courseTable.setModel(tableModel);

        JScrollPane courseScrollPane = new JScrollPane(courseTable);
        enrollButton = new JButton("Enroll");
        enrollButton.setFont(new Font("Arial", Font.BOLD, 16));
        enrollButton.setBackground(new Color(0, 128, 0));
        enrollButton.setForeground(Color.WHITE);


        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(titleLabel, BorderLayout.CENTER);

        JPanel coursePanel = new JPanel(new BorderLayout());
        coursePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        coursePanel.add(courseComboBox, BorderLayout.NORTH);
        coursePanel.add(courseScrollPane, BorderLayout.CENTER);
        coursePanel.add(enrollButton, BorderLayout.SOUTH);

        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(coursePanel, BorderLayout.CENTER);

        enrollButton.addActionListener(this);

        // Populate the combobox with courses
        populateCourseComboBox();

        // Populate the table with course information
        populateCourseTable();

        // Disable the Enroll button until a course is selected
        enrollButton.setEnabled(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enrollButton) {
            String selectedCourse = (String) courseComboBox.getSelectedItem();
            if (selectedCourse != null) {
                // Attempt to enroll the student in the selected course
                if (enrollStudentInCourse(selectedCourse)) {
                    JOptionPane.showMessageDialog(this, "Enrollment successful!");
                } else {
                    JOptionPane.showMessageDialog(this, "Enrollment failed. You may have already enrolled in this course.");
                }
            }
        }
    }

    private void populateCourseComboBox() {
        ArrayList<String> courseNames = generateCourseNames();
        for (String courseName : courseNames) {
            courseComboBox.addItem(courseName);
        }
    }

    private void populateCourseTable() {
        ArrayList<Course> courses = generateCoursesWithDescriptions();
        for (Course course : courses) {
            tableModel.addRow(new Object[]{course.getCourseName(), course.getID()});
        }
    }

    private ArrayList<String> generateCourseNames() {
        ArrayList<String> courseNames = new ArrayList<>();
        courseNames.add("Mathematics");
        courseNames.add("Physics");
        courseNames.add("Chemistry");
        courseNames.add("Biology");
        courseNames.add("History");
        courseNames.add("Literature");
        courseNames.add("Computer Science");
        courseNames.add("Art");
        courseNames.add("Music");
        return courseNames;
    }

    private ArrayList<Course> generateCoursesWithDescriptions() {
        ArrayList<Course> courses = new ArrayList<>();
        courses.add(new Course("Mathematics", "Math is fun!", ""));
        courses.add(new Course("Physics", "Explore the laws of the universe.", ""));
        courses.add(new Course("Chemistry", "Discover the world of elements and compounds.", ""));
        courses.add(new Course("Biology", "Study life in all its forms.", ""));
        courses.add(new Course("History", "Learn about the past and its impact on the present.", ""));
        courses.add(new Course("Literature", "Immerse yourself in the world of words and stories.", ""));
        courses.add(new Course("Computer Science", "Master the art of coding.", ""));
        courses.add(new Course("Art", "Express your creativity through art.", ""));
        courses.add(new Course("Music", "Discover the world of sound and melody.", ""));
        return courses;
    }

    private boolean enrollStudentInCourse(String courseName) {
        // Replace with your actual database connection details
        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String password = "password";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Subjects (CourseName, Description) VALUES (?, ?)");

            preparedStatement.setString(1, courseName);
            preparedStatement.setString(2, "Course description for " + courseName);

            int rowsInserted = preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

            return rowsInserted > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentPage studentPage = new StudentPage();
            studentPage.setVisible(true);
        });
    }   } 