package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {
    private static final String DB_URL = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
    private static final String DB_USERNAME = "Administrator";
    private static final String DB_PASSWORD = "123456";
    private static final int MAX_CONNECTIONS = 10;
    
    private static BlockingQueue<Connection> connectionPool = new ArrayBlockingQueue<>(MAX_CONNECTIONS);
    
    private static Logger logger = Logger.getLogger(DBConnection.class.getName());
    
    static {
        try {
            // Load the database driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            // Initialize the connection pool
            for (int i = 0; i < MAX_CONNECTIONS; i++) {
                Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/StudentEnrolmentDB", "Administrator", "123456");
                connectionPool.offer(connection);
            }
        } catch (ClassNotFoundException | SQLException e) {
            logger.log(Level.SEVERE, "Failed to initialize the connection pool.", e);
            throw new ExceptionInInitializerError(e);
        }
    }
    
    public static Connection getConnection() throws SQLException {
        Connection connection = connectionPool.poll();
        if (connection == null) {
            logger.warning("No available database connections in the pool.");
            throw new SQLException("No available database connections.");
        }
        return connection;
    }
    
    
    public static void releaseConnection(Connection connection) {
    if (connection != null) {
        try {
            if (!connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to close the connection.", e);
        } finally {
            connectionPool.offer(connection);
        }
    }
}

    public static void close() {
        for (Connection connection : connectionPool) {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Failed to close a connection in the pool.", e);
            }
        }
        connectionPool.clear();
    }
}
