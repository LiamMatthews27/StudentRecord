package StudentEnrollmentDAO;

public class UserDAO {
    
    // Simulate user data (you should replace this with database access)
    private static final String studentUsernameDB = "student";
    private static final String studentPasswordDB = "studentpass";
    private static final String adminUsernameDB = "admin";
    private static final String adminPasswordDB = "adminpass";

    public static int authenticateUser(String username, String password) {
        // Simulate user authentication (replace with database access)
        if (studentUsernameDB.equals(username) && studentPasswordDB.equals(password)) {
            return 0; // Student role
        } else if (adminUsernameDB.equals(username) && adminPasswordDB.equals(password)) {
            return 1; // Admin role
        } else {
            return -1; // Authentication failed
        }
    }

    public static void main(String[] args) {
        // Replace these with your actual credentials
        String studentUsername = "student"; // Change to your student username
        String studentPassword = "studentpass"; // Change to your student password

        String adminUsername = "admin"; // Change to your admin username
        String adminPassword = "adminpass"; // Change to your admin password

        int studentRole = authenticateUser(studentUsername, studentPassword);
        int adminRole = authenticateUser(adminUsername, adminPassword);

        if (studentRole == 0) {
            // Student login successful
            System.out.println("Student logged in.");
            // Implement logic for the student's interface
        } else if (adminRole == 1) {
            // Admin login successful
            System.out.println("Admin logged in.");
            // Implement logic for the admin's interface
        } else {
            // Authentication failed for both roles
            System.out.println("Authentication failed. Invalid username or password.");
        }
    }
}


