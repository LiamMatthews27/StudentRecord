package StudentEnrollmentDAO;

import DBConnection.DBConnection;
import EnrollmentServer.Course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    public static List<Course> getAllCourses() {
    List<Course> courses = new ArrayList<>();
    String query = "SELECT * FROM courses";

    try (Connection connection = DBConnection.getConnection();
         PreparedStatement statement = connection.prepareStatement(query);
         ResultSet resultSet = statement.executeQuery()) {

        while (resultSet.next()) {
            String courseID = resultSet.getString("course_id");
            String courseDescription = resultSet.getString("course_description");

            Course course = new Course(courseID, courseDescription, "");
            courses.add(course);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return courses;
}


    public static Course getCourseById(String courseID) {
        String query = "SELECT * FROM courses WHERE course_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, courseID);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String courseDescription = resultSet.getString("course_description");
                    return new Course(courseID, courseDescription, "");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null; // Course not found
    }

    public static boolean updateCourse(Course course) {
        String query = "UPDATE courses SET course_description = ? WHERE course_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, course.getCourseName());
            statement.setString(2, course.getID());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteCourse(String courseID) {
        String query = "DELETE FROM courses WHERE course_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, courseID);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  

    public static Course getCourseByDescription(String courseDescription) {
        String query = "SELECT * FROM courses WHERE course_description = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, courseDescription);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String courseID = resultSet.getString("course_id");
                    return new Course(courseID, courseDescription, "");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null; // Course not found
    }
}
