/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package StudentEnrollmentDAO;

import ClientSide.Student;
import DBConnection.DBConnection;
import EnrollmentServer.Course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public static List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String query = "SELECT * FROM students";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String studentName = resultSet.getString("studentName");
                String studentLastName = resultSet.getString("studentLastName");
                String studentNumber = resultSet.getString("studentNumber");
                String studentEmail = resultSet.getString("studentEmail");

                Student student = new Student(studentName, studentLastName, studentNumber, studentEmail, "");
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }

    public static boolean addStudent(Student student) {
        String query = "INSERT INTO students (studentName, studentLastName, studentNumber, studentEmail, studentPassword) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, student.getStudentName());
            statement.setString(2, student.getStudentLastName());
            statement.setString(3, student.getStudentNumber());
            statement.setString(4, student.getStudentEmail());
            statement.setString(5, student.getStudentPassword());

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Student getStudentById(String studentNumber) {
        // Define SQL query to retrieve student data by student number
        String query = "SELECT * FROM students WHERE studentNumber = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, studentNumber);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String studentName = resultSet.getString("studentName");
                    String studentLastName = resultSet.getString("studentLastName");
                    String studentEmail = resultSet.getString("studentEmail");
                    String studentPassword = resultSet.getString("studentPassword");
                    // Create a Student object and return it
                    return new Student(studentName, studentLastName, studentNumber, studentEmail, studentPassword);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null; // Student not found
    }

    public static boolean updateStudent(Student student) {
        // Define SQL query to update student information
        String query = "UPDATE students SET studentName = ?, studentLastName = ?, studentEmail = ?, studentPassword = ? WHERE studentNumber = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, student.getStudentName());
            statement.setString(2, student.getStudentLastName());
            statement.setString(3, student.getStudentEmail());
            statement.setString(4, student.getStudentPassword());
            statement.setString(5, student.getStudentNumber());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteStudent(String studentNumber) {
        // Define SQL query to delete a student by student number
        String query = "DELETE FROM students WHERE studentNumber = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, studentNumber);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Course> getEnrolledCourses(String studentNumber) {
        List<Course> enrolledCourses = new ArrayList<>();
        // Define SQL query to fetch enrolled courses for a student
        String query = "SELECT c.* FROM courses c INNER JOIN enrollment e ON c.course_id = e.course_id WHERE e.studentNumber = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, studentNumber);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String courseID = resultSet.getString("course_id");
                    String courseDescription = resultSet.getString("course_description");
                    enrolledCourses.add(new Course(courseID, courseDescription, ""));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return enrolledCourses;
    }

}
