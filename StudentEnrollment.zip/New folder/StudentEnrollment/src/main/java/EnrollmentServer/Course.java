/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnrollmentServer;
import java.io.Serializable;

public class Course implements Serializable {

    private String ID;
    private String CourseID ;
    private String CourseName ;

    @Override
    public String toString() {
        return "Course{" + "ID=" + ID + ", CourseID=" + CourseID + ", CourseName=" + CourseName + '}';
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getCourseID() {
        return CourseID;
    }

    public void setCourseID(String CourseID) {
        this.CourseID = CourseID;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String CourseName) {
        this.CourseName = CourseName;
    }

    public Course(String ID, String CourseID, String CourseName) {
        this.ID = ID;
        this.CourseID = CourseID;
        this.CourseName = CourseName;
    }
}


