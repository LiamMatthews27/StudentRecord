package EnrollmentServer;


import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StudentEnrollmentServer {
    private ServerSocket serverSocket;
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    public StudentEnrollmentServer() {
        try {
            serverSocket = new ServerSocket(1527); // Replace with your desired port
            System.out.println("Server is running. Waiting for clients...");

            while (true) {
                socket = serverSocket.accept();
                System.out.println("Client connected.");

                in = new ObjectInputStream(socket.getInputStream());
                out = new ObjectOutputStream(socket.getOutputStream());

                handleClientRequests();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleClientRequests() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException ex) {
            Logger.getLogger(StudentEnrollmentServer.class.getName()).log(Level.SEVERE, null, ex);
        }

        while (true) {
            try {
                String request = (String) in.readObject();

                switch (request) {
                    case "Authenticate User":
                        authenticateUser();
                        break;
                    case "Add Student":
                        addStudentToDatabase();
                        break;
                    case "Add Course":
                        addCourseToDatabase();
                        break;

                    default:
                        out.writeObject("Error: Unknown Request");
                        break;
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void authenticateUser() {
        try {
            String username = (String) in.readObject();
            String password = (String) in.readObject();

            String role = handleAuthentication(username, password);
            out.writeObject(role);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String handleAuthentication(String username, String password) {
        try {
           
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/StudentenrollmentDB", "Administrator", "123456");
            PreparedStatement stmt = conn.prepareStatement("SELECT role FROM users WHERE username = ? AND password = ?");
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("role");
            } else {
                return "Error";
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return "Error";
        }
    }

    private void addStudentToDatabase() {
        try {
            String firstName = (String) in.readObject();
            String lastName = (String) in.readObject();
            String studentID = (String) in.readObject();
            String email = (String) in.readObject();
            String password = (String) in.readObject();

            String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
            String username = "Administrator";
            String dbpassword = "123456";

            String query = "INSERT INTO students (name, lastname, studentID, email, password) VALUES (?, ?, ?, ?, ?)";

            try {
                Connection connection = DriverManager.getConnection(url, username, dbpassword);
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, firstName);
                statement.setString(2, lastName);
                statement.setString(3, studentID);
                statement.setString(4, email);
                statement.setString(5, password);

                statement.executeUpdate();

                statement.close();
                connection.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

  private void addCourseToDatabase() {
    try {
        String courseID = (String) in.readObject();
        String courseName = (String) in.readObject();

        String url = "jdbc:derby://localhost:1527/StudentEnrolmentDB";
        String username = "Administrator";
        String password = "123456";

        String query = "INSERT INTO course (courseID, courseName) VALUES (?, ?)";

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, courseID);
            statement.setString(2, courseName);

            statement.executeUpdate();

            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    } catch (IOException | ClassNotFoundException e) {
        e.printStackTrace();
    }
}


    public static void main(String[] args) {
        new StudentEnrollmentServer();
    }
}
